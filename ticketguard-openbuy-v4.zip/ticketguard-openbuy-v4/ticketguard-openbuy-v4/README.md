# TicketGuard OpenBuy

Sistema de gestión de eventos y entradas con enfoque tipo marketplace/OpenBuy. Cada evento funciona como un foro donde los vendedores publican ofertas de entradas con links externos. El sistema actúa como honeypot controlado: registra publicaciones, analiza links y muestra alertas administrativas cuando detecta indicadores de phishing, scam o malware.

## Tecnologías utilizadas

- Backend: Go, Gin, GORM, MySQL, JWT y bcrypt.
- Frontend: React + Vite.
- Base de datos: MySQL 8.
- DevOps: Docker, Dockerfile y Docker Compose.
- Seguridad extra del proyecto: cliente de análisis de links para ofertas externas, con implementación mock local y adaptación preparada para VirusTotal si se configura `VT_API_KEY`.

## Estructura del proyecto

```text
ticketguard-openbuy/
├── backend/
│   ├── clients/        # clientes externos, como análisis de links
│   ├── config/         # variables de entorno y conexión
│   ├── controllers/    # handlers HTTP
│   ├── dao/            # acceso a datos con GORM
│   ├── domain/         # entidades del negocio
│   ├── middleware/     # autenticación/autorización
│   ├── services/       # lógica de negocio
│   ├── utils/          # JWT, password y respuestas
│   └── main.go
├── frontend/
│   └── src/
├── docs/
├── docker-compose.yml
├── .env.example
└── .env              # incluido solo para correr local con Docker
```

## Cómo levantar todo

1. El ZIP ya trae un `.env` de desarrollo para que Docker Compose levante sin error. Si querés regenerarlo, copiá `.env.example` como `.env`.

2. Levantá el sistema completo:

```bash
docker compose build --no-cache
docker compose up
```

3. Abrí el frontend:

```text
http://localhost:5173
```

4. API backend:

```text
http://localhost:8080/api
```

5. MySQL desde DBeaver/TablePlus, si querés inspeccionar:

```text
Host: localhost
Port: 3307
User: ticketguard
Password: ticketguard123
Database: ticketguard_db
```

## Usuarios iniciales cargados por seed

```text
Admin:    admin@ticketguard.test    / Admin123!
Vendedor: seller@ticketguard.test   / Seller123!
Cliente:  cliente@ticketguard.test  / Cliente123!
```

## Flujo de prueba sugerido

1. Entrar como admin y crear o editar eventos.
2. Entrar como vendedor y crear una oferta para un evento.
3. Entrar como vendedor y pegar una URL larga o sospechosa en una publicación para probar el flujo de alerta.
4. Entrar como cliente, cargar saldo en el monedero, comprar una oferta y luego ver “Mis Entradas”.
5. Cancelar una entrada o transferirla a otro usuario por email.
6. Entrar como admin y ver reportes y alertas del honeypot.

## Endpoints principales

### Autenticación

```text
POST /api/auth/register
POST /api/auth/login
```

### Público

```text
GET /api/events
GET /api/events/:id
GET /api/events/:id/offers
```

### Usuario autenticado

```text
GET  /api/me/wallet
POST /api/me/wallet/deposit
```

### Cliente autenticado

```text
POST /api/offers/:id/buy
GET  /api/me/tickets
POST /api/tickets/:id/cancel
POST /api/tickets/:id/transfer
```

### Vendedor

```text
GET  /api/seller/offers
POST /api/seller/offers
```

### Administrador

```text
POST   /api/admin/events
PUT    /api/admin/events/:id
DELETE /api/admin/events/:id
GET    /api/admin/events/:id/report
GET    /api/admin/security/offers
```

## Tests del backend

```bash
cd backend
go test ./...
```

También podés obtener cobertura:

```bash
go test ./... -cover
```

## Decisiones de diseño

1. Las compras, cancelaciones y transferencias se resuelven en la capa de servicios. Los controladores solo parsean HTTP, validan entrada superficial y devuelven status codes.
2. La capa DAO encapsula GORM y evita que los controladores tengan consultas o SQL.
3. La sesión sin autenticar solo explora el catálogo público. Las acciones sensibles están separadas por rol: cliente compra y gestiona entradas, vendedor publica ofertas y administrador gestiona eventos/reportes/alertas.
4. Los tickets no se eliminan físicamente cuando se cancelan: pasan a estado `cancelled`. Esto conserva historial y permite que el reporte sea auditable.
5. Las compras usan monedero: se descuenta saldo al cliente y se acredita al vendedor dentro de una transacción.
6. Las contraseñas se guardan con bcrypt, no en texto plano.
7. Los links publicados por vendedores pasan por un `LinkScanner`. Sin API key funciona con un mock local; con `VT_API_KEY` queda preparado para integrar VirusTotal.

## Diagrama de base de datos

El diagrama fuente está en:

```text
docs/db-diagram.mmd
```

Podés pegarlo en un visor Mermaid para exportarlo como imagen e incrustarlo en el README final del repositorio.

## Ajustes v4 de interfaz y permisos

Esta versión aplica el feedback visual marcado sobre la captura:

- Se eliminó la ubicación superior derecha del marketplace.
- Se eliminó cualquier chip inferior que muestre el usuario activo o su rol.
- El botón de configuración ya no queda sin acción: abre la vista de cuenta.
- La opción **Crear publicación** aparece únicamente en sesión de vendedor.
- La opción **Mis entradas** aparece únicamente en sesión de cliente.
- La sesión sin login solo puede explorar eventos públicos; no puede comprar, publicar, ver entradas, cargar monedero ni acceder a alertas. Además, v4 invalida tokens guardados de versiones anteriores para que no quede una sesión vieja activa al abrir la app.
- El monedero queda disponible para sesiones autenticadas y se usa para compras y acreditación al vendedor.
- Los eventos funcionan como foros donde los vendedores publican ofertas con links externos largos, manteniendo el enfoque honeypot para detectar phishing/scams.



## Corrección específica del error `vite: not found`

La versión 4 ajusta el `frontend/Dockerfile` para instalar dependencias dentro de la imagen y ejecutar solamente:

```bash
npm run dev
```

Si venís de una imagen rota anterior, reconstruí sin cache:

```bash
docker compose down -v
docker compose build --no-cache
docker compose up
```
