package services

import (
	"fmt"

	"ticketguard/backend/dao"
	"ticketguard/backend/domain"
	"ticketguard/backend/utils"
)

type WalletService struct {
	users *dao.UserDAO
}

type WalletResponse struct {
	UserID  uint    `json:"user_id"`
	Balance float64 `json:"balance"`
}

type DepositInput struct {
	Amount float64 `json:"amount" binding:"required"`
}

func NewWalletService(users *dao.UserDAO) *WalletService {
	return &WalletService{users: users}
}

func (s *WalletService) Get(userID uint) (*WalletResponse, error) {
	user, err := s.users.FindByID(userID)
	if err != nil {
		return nil, err
	}
	return walletFromUser(user), nil
}

func (s *WalletService) Deposit(userID uint, input DepositInput) (*WalletResponse, error) {
	if input.Amount <= 0 {
		return nil, fmt.Errorf("%w: amount must be greater than zero", utils.ErrInvalidInput)
	}
	user, err := s.users.FindByID(userID)
	if err != nil {
		return nil, err
	}
	user.Balance += input.Amount
	if err := s.users.Update(user); err != nil {
		return nil, err
	}
	return walletFromUser(user), nil
}

func walletFromUser(user *domain.User) *WalletResponse {
	return &WalletResponse{UserID: user.ID, Balance: user.Balance}
}
