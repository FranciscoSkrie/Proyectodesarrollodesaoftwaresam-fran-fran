package controllers

import (
	"ticketguard/backend/services"
	"ticketguard/backend/utils"

	"github.com/gin-gonic/gin"
)

type WalletController struct{ service *services.WalletService }

func NewWalletController(service *services.WalletService) *WalletController {
	return &WalletController{service: service}
}

func (h *WalletController) Get(c *gin.Context) {
	wallet, err := h.service.Get(currentUserID(c))
	if err != nil {
		utils.Error(c, err)
		return
	}
	utils.OK(c, wallet)
}

func (h *WalletController) Deposit(c *gin.Context) {
	var input services.DepositInput
	if err := c.ShouldBindJSON(&input); err != nil {
		utils.Error(c, utils.ErrInvalidInput)
		return
	}
	wallet, err := h.service.Deposit(currentUserID(c), input)
	if err != nil {
		utils.Error(c, err)
		return
	}
	utils.OK(c, wallet)
}
