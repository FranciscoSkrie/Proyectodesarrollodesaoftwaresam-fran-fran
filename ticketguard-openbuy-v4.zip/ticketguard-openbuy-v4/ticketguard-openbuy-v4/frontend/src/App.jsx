import { useEffect, useMemo, useState } from 'react'
import { api } from './api.js'

const emptyEvent = {
  title: '',
  description: '',
  category: '',
  location: '',
  starts_at: '',
  duration_minutes: 120,
  capacity: 100,
  image_url: ''
}

const SESSION_VERSION = 'ticketguard-openbuy-v4'

function clearStoredSession() {
  localStorage.removeItem('token')
  localStorage.removeItem('user')
  localStorage.removeItem('session_version')
}

function loadStoredSession() {
  const version = localStorage.getItem('session_version')
  const token = localStorage.getItem('token')
  const user = localStorage.getItem('user')

  // v4 corta cualquier sesión vieja de versiones anteriores: la sesión default arranca sin permisos.
  if (version !== SESSION_VERSION || !token || !user) {
    clearStoredSession()
    return null
  }

  try {
    return { token, user: JSON.parse(user) }
  } catch {
    clearStoredSession()
    return null
  }
}

function App() {
  const [session, setSession] = useState(loadStoredSession)
  const [view, setView] = useState('home')
  const [events, setEvents] = useState([])
  const [selectedEvent, setSelectedEvent] = useState(null)
  const [offers, setOffers] = useState([])
  const [tickets, setTickets] = useState([])
  const [sellerOffers, setSellerOffers] = useState([])
  const [wallet, setWallet] = useState(() => session ? { balance: session.user.balance || 0 } : null)
  const [report, setReport] = useState(null)
  const [securityAlerts, setSecurityAlerts] = useState([])
  const [message, setMessage] = useState('')
  const [filters, setFilters] = useState({ q: '', category: '' })

  const role = session?.user?.role || 'anon'
  const isClient = role === 'cliente'
  const isSeller = role === 'vendedor'
  const isAdmin = role === 'admin'

  async function loadEvents(nextFilters = filters) {
    try {
      setEvents(await api.events(nextFilters))
    } catch (err) {
      setMessage(err.message)
    }
  }

  async function loadWallet() {
    if (!session) return
    try {
      const data = await api.wallet()
      setWallet(data)
      const updatedUser = { ...session.user, balance: data.balance }
      localStorage.setItem('user', JSON.stringify(updatedUser))
      setSession(prev => prev ? { ...prev, user: updatedUser } : prev)
    } catch (err) {
      setMessage(err.message)
    }
  }

  useEffect(() => { loadEvents() }, [])

  function saveSession(resp) {
    localStorage.setItem('session_version', SESSION_VERSION)
    localStorage.setItem('token', resp.token)
    localStorage.setItem('user', JSON.stringify(resp.user))
    setSession(resp)
    setWallet({ balance: resp.user.balance || 0 })
    setView('account')
    setMessage('Sesión iniciada correctamente')
  }

  function logout() {
    clearStoredSession()
    setSession(null)
    setWallet(null)
    setTickets([])
    setSellerOffers([])
    setSecurityAlerts([])
    setView('home')
    setMessage('Sesión cerrada')
  }

  async function openEvent(event) {
    try {
      setSelectedEvent(event)
      setOffers(await api.offers(event.id))
      setView('detail')
    } catch (err) {
      setMessage(err.message)
    }
  }

  async function loadTickets() {
    if (!isClient) {
      setMessage('Para ver entradas tenés que usar una cuenta de cliente')
      return
    }
    try {
      setTickets(await api.myTickets())
      setView('tickets')
    } catch (err) {
      setMessage(err.message)
    }
  }

  async function loadSellerOffers() {
    if (!isSeller) {
      setMessage('Solo una cuenta de vendedor puede crear publicaciones')
      return
    }
    try {
      setSellerOffers(await api.sellerOffers())
      setView('seller')
    } catch (err) {
      setMessage(err.message)
    }
  }

  async function loadReport(eventId) {
    try {
      setReport(await api.report(eventId))
    } catch (err) {
      setMessage(err.message)
    }
  }

  async function loadSecurityAlerts() {
    try {
      setSecurityAlerts(await api.securityOffers())
    } catch (err) {
      setMessage(err.message)
    }
  }

  function goPublish() {
    if (!session) {
      setView('login')
      setMessage('Iniciá sesión como vendedor para crear publicaciones')
      return
    }
    if (!isSeller) {
      setMessage('Solo una cuenta de vendedor puede crear publicaciones')
      return
    }
    loadSellerOffers()
  }

  function goWallet() {
    if (!session) {
      setView('login')
      setMessage('Iniciá sesión para acceder al monedero')
      return
    }
    loadWallet()
    setView('wallet')
  }

  function goAdmin() {
    if (!isAdmin) {
      setMessage('Solo administración puede ver el panel de gestión')
      return
    }
    loadSecurityAlerts()
    setView('admin')
  }

  function goAccount() {
    if (!session) {
      setView('login')
      return
    }
    loadWallet()
    setView('account')
  }

  function requireLogin() {
    setView('login')
    setMessage('Iniciá sesión con una cuenta de cliente para comprar')
  }

  return (
    <div className="market-shell">
      <Sidebar
        session={session}
        view={view}
        filters={filters}
        setFilters={setFilters}
        onSearch={loadEvents}
        setView={setView}
        onAccount={goAccount}
        onTickets={loadTickets}
        onPublish={goPublish}
        onWallet={goWallet}
        onAdmin={goAdmin}
        isClient={isClient}
        isSeller={isSeller}
        isAdmin={isAdmin}
        onLogout={logout}
      />

      <main className="content">
        <div className="content-top">
          <h2>{titleFor(view)}</h2>
        </div>

        {message && <div className="message" onClick={() => setMessage('')}>{message}</div>}

        {view === 'home' && <Home events={events} onOpen={openEvent} />}
        {view === 'login' && <Login onLogin={saveSession} setMessage={setMessage} />}
        {view === 'account' && <Account session={session} wallet={wallet} onWallet={goWallet} onTickets={loadTickets} onPublish={goPublish} onAdmin={goAdmin} onLogout={logout} isClient={isClient} isSeller={isSeller} isAdmin={isAdmin} />}
        {view === 'wallet' && <Wallet wallet={wallet} reload={loadWallet} setMessage={setMessage} />}
        {view === 'detail' && <Detail event={selectedEvent} offers={offers} session={session} isClient={isClient} onRequireLogin={requireLogin} onBuy={async (id) => {
          try {
            await api.buy(id)
            setMessage('Compra realizada correctamente. El importe se descontó del monedero.')
            await loadWallet()
            await loadTickets()
          } catch (err) {
            setMessage(err.message)
          }
        }} />}
        {view === 'tickets' && <Tickets tickets={tickets} onCancel={async (id) => {
          try {
            await api.cancelTicket(id)
            setMessage('Entrada cancelada. El importe volvió al monedero.')
            await loadWallet()
            await loadTickets()
          } catch (err) {
            setMessage(err.message)
          }
        }} onTransfer={async (id, email) => {
          try {
            await api.transferTicket(id, email)
            setMessage('Entrada transferida')
            await loadTickets()
          } catch (err) {
            setMessage(err.message)
          }
        }} />}
        {view === 'seller' && <Seller events={events} offers={sellerOffers} reload={loadSellerOffers} setMessage={setMessage} />}
        {view === 'admin' && <Admin events={events} reloadEvents={loadEvents} report={report} loadReport={loadReport} alerts={securityAlerts} reloadAlerts={loadSecurityAlerts} setMessage={setMessage} />}
      </main>
    </div>
  )
}

function titleFor(view) {
  const titles = {
    home: 'Foros de eventos destacados',
    login: 'Tu cuenta',
    account: 'Tu cuenta',
    wallet: 'Monedero',
    detail: 'Publicaciones del evento',
    tickets: 'Mis entradas',
    seller: 'Crear publicación',
    admin: 'Panel de gestión y alertas'
  }
  return titles[view] || 'Marketplace'
}

function Sidebar({ session, view, filters, setFilters, onSearch, setView, onAccount, onTickets, onPublish, onWallet, onAdmin, isClient, isSeller, isAdmin, onLogout }) {
  function submit(e) {
    e.preventDefault()
    onSearch()
    setView('home')
  }

  function setCategory(category) {
    const next = { ...filters, category }
    setFilters(next)
    onSearch(next)
    setView('home')
  }

  return (
    <aside className="sidebar">
      <div className="brand-row">
        <h1>Marketplace</h1>
        <button className="round-btn" title="Configuración de cuenta" aria-label="Abrir cuenta o iniciar sesión" onClick={onAccount}>⚙</button>
      </div>

      <form className="search-box" onSubmit={submit}>
        <span>⌕</span>
        <input
          placeholder="Buscar en Marketplace"
          value={filters.q}
          onChange={e => setFilters({ ...filters, q: e.target.value })}
        />
      </form>

      <div className="side-menu">
        <button className={view === 'home' ? 'side-active' : ''} onClick={() => { setView('home'); onSearch() }}>🏪 Explorar todo</button>
        <button className={view === 'account' || view === 'login' ? 'side-active' : ''} onClick={onAccount}>👤 Tu cuenta</button>
        {isSeller && <button className="create-btn" onClick={onPublish}>＋ Crear publicación</button>}
        {isClient && <button className={view === 'tickets' ? 'side-active' : ''} onClick={onTickets}>🎟️ Mis entradas</button>}
        {session && <button className={view === 'wallet' ? 'side-active' : ''} onClick={onWallet}>💳 Monedero</button>}
        {isAdmin && <button className={view === 'admin' ? 'side-active' : ''} onClick={onAdmin}>🛡️ Gestión y alertas</button>}
        {session && <button onClick={onLogout}>↩ Salir</button>}
      </div>

      <hr />

      <section className="sidebar-section">
        <h3>Filtros</h3>
        <input
          placeholder="Categoría"
          value={filters.category}
          onChange={e => setFilters({ ...filters, category: e.target.value })}
        />
        <button onClick={() => { onSearch(); setView('home') }}>Aplicar filtros</button>
      </section>

      <section className="sidebar-section categories">
        <h3>Categorías</h3>
        <button onClick={() => setCategory('Tecnología')}>💻 Tecnología</button>
        <button onClick={() => setCategory('Música')}>🎵 Música</button>
        <button onClick={() => setCategory('Deportes')}>⚽ Deportes</button>
        <button onClick={() => setCategory('Teatro')}>🎭 Teatro</button>
        <button onClick={() => setCategory('Gaming')}>🎮 Gaming</button>
        <button onClick={() => setCategory('Conferencias')}>🎤 Conferencias</button>
      </section>
    </aside>
  )
}

function Home({ events, onOpen }) {
  return (
    <section className="market-grid">
      {events.length === 0 && <div className="empty-state">No se encontraron eventos con esos filtros.</div>}
      {events.map(event => <article className="listing-card" key={event.id} onClick={() => onOpen(event)}>
        <div className="thumb">
          {event.image_url ? <img src={event.image_url} alt={event.title} /> : <span>{event.category || 'Evento'}</span>}
        </div>
        <div className="listing-body">
          <strong>{event.title}</strong>
          <p>{event.location}</p>
          <small>{new Date(event.starts_at).toLocaleString()} · {event.category}</small>
          <small>Foro abierto para publicaciones de vendedores</small>
        </div>
      </article>)}
    </section>
  )
}

function Login({ onLogin, setMessage }) {
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ name: '', email: 'cliente@ticketguard.test', password: 'Cliente123!', role: 'cliente' })
  async function submit(e) {
    e.preventDefault()
    try {
      const resp = mode === 'login' ? await api.login(form) : await api.register(form)
      onLogin(resp)
    } catch (err) {
      setMessage(err.message)
    }
  }
  return <section className="panel narrow-panel">
    <h2>{mode === 'login' ? 'Iniciar sesión' : 'Crear cuenta'}</h2>
    <p className="hint">Sin iniciar sesión solo se puede explorar el catálogo público. Comprar, publicar, ver entradas y gestionar alertas queda bloqueado hasta autenticar la cuenta correcta.</p>
    <form onSubmit={submit}>
      {mode === 'register' && <input placeholder="Nombre" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />}
      <input placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
      <input placeholder="Password" type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
      {mode === 'register' && <select value={form.role} onChange={e => setForm({ ...form, role: e.target.value })}>
        <option value="cliente">Cuenta para comprar</option>
        <option value="vendedor">Cuenta para publicar</option>
      </select>}
      <button>{mode === 'login' ? 'Entrar' : 'Registrarme'}</button>
    </form>
    <button className="text-btn" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Crear una cuenta' : 'Ya tengo cuenta'}</button>
    <div className="demo-box">
      <p><strong>Demo</strong></p>
      <p>admin@ticketguard.test / Admin123!</p>
      <p>seller@ticketguard.test / Seller123!</p>
      <p>cliente@ticketguard.test / Cliente123!</p>
    </div>
  </section>
}

function Account({ session, wallet, onWallet, onTickets, onPublish, onAdmin, onLogout, isClient, isSeller, isAdmin }) {
  if (!session) return null
  return <section className="account-grid">
    <div className="panel account-main">
      <h2>Cuenta conectada</h2>
      <p className="hint">Desde acá se accede solo a las acciones habilitadas para esta sesión.</p>
      <div className="account-summary">
        <span>Correo</span>
        <strong>{session.user.email}</strong>
      </div>
      <div className="account-summary wallet-summary">
        <span>Saldo del monedero</span>
        <strong>${formatMoney(wallet?.balance || 0)}</strong>
      </div>
      <div className="account-actions">
        <button onClick={onWallet}>Abrir monedero</button>
        {isClient && <button onClick={onTickets}>Ver mis entradas</button>}
        {isSeller && <button onClick={onPublish}>Crear publicación</button>}
        {isAdmin && <button onClick={onAdmin}>Ver gestión y alertas</button>}
        <button className="secondary-btn" onClick={onLogout}>Salir</button>
      </div>
    </div>
    <div className="panel account-help">
      <h2>Accesos por sesión</h2>
      <p>La sesión sin login solo puede explorar eventos. Las compras, publicaciones, monedero, entradas y alertas se validan contra el backend.</p>
      <p>Las publicaciones de vendedores funcionan como un honeypot: el link externo se analiza y queda registrado como evidencia si resulta sospechoso.</p>
    </div>
  </section>
}

function Wallet({ wallet, reload, setMessage }) {
  const [amount, setAmount] = useState(10000)
  async function submit(e) {
    e.preventDefault()
    try {
      await api.deposit(Number(amount))
      setMessage('Saldo agregado al monedero')
      await reload()
    } catch (err) {
      setMessage(err.message)
    }
  }
  return <section className="panel narrow-panel wallet-panel">
    <h2>Monedero</h2>
    <div className="wallet-balance">${formatMoney(wallet?.balance || 0)}</div>
    <p className="hint">Este saldo se usa para simular compras dentro del sistema. Al comprar una entrada se descuenta del cliente y se acredita al vendedor.</p>
    <form onSubmit={submit}>
      <input type="number" min="1" value={amount} onChange={e => setAmount(e.target.value)} />
      <button>Agregar saldo</button>
    </form>
  </section>
}

function Detail({ event, offers, session, isClient, onRequireLogin, onBuy }) {
  if (!event) return null
  return <div className="detail-layout">
    <section className="panel detail-panel">
      {event.image_url && <img className="detail-image" src={event.image_url} alt={event.title} />}
      <h2>{event.title}</h2>
      <p>{event.description}</p>
      <div className="meta-list">
        <span><strong>Lugar</strong>{event.location}</span>
        <span><strong>Fecha</strong>{new Date(event.starts_at).toLocaleString()}</span>
        <span><strong>Cupo</strong>{event.capacity}</span>
      </div>
    </section>
    <section className="panel">
      <h2>Publicaciones de vendedores</h2>
      {offers.length === 0 && <p>No hay publicaciones activas.</p>}
      {offers.map(offer => <OfferRow offer={offer} key={offer.id} session={session} isClient={isClient} onRequireLogin={onRequireLogin} onBuy={onBuy} />)}
      {!session && <p className="hint">Para comprar necesitás iniciar sesión con una cuenta de cliente.</p>}
      {session && !isClient && <p className="hint">Esta cuenta puede explorar, pero solo una cuenta de cliente puede comprar entradas.</p>}
    </section>
  </div>
}

function OfferRow({ offer, session, isClient, onRequireLogin, onBuy }) {
  const riskClass = offer.scan_status === 'malicious' ? 'danger' : offer.scan_status === 'suspicious' ? 'warning' : offer.scan_status === 'pending' ? 'pending' : 'safe'
  const blocked = offer.status === 'blocked' || offer.quantity <= 0
  const canBuy = Boolean(session && isClient && !blocked)
  const label = offer.status === 'blocked' ? 'Bloqueada' : !session ? 'Iniciar sesión' : !isClient ? 'Solo clientes' : offer.quantity <= 0 ? 'Sin cupo' : 'Comprar'
  const disabled = Boolean(session && (!isClient || blocked))
  return <div className="offer-row">
    <div>
      <strong>{offer.title}</strong>
      <p>${formatMoney(offer.price)} · disponibles: {offer.quantity}</p>
      <span className={`scan-badge ${riskClass}`}>{offer.scan_status}</span>
      <small>{offer.scan_verdict}</small>
    </div>
    <button disabled={disabled} onClick={() => canBuy ? onBuy(offer.id) : onRequireLogin()}>{label}</button>
  </div>
}

function Tickets({ tickets, onCancel, onTransfer }) {
  const [emailByTicket, setEmailByTicket] = useState({})
  return <section className="panel">
    <h2>Mis entradas</h2>
    {tickets.length === 0 && <p>Todavía no tenés entradas.</p>}
    {tickets.map(ticket => <div className="table-row" key={ticket.id}>
      <div>
        <strong>{ticket.event?.title}</strong>
        <p>Código: {ticket.code} · Estado: {ticket.status} · ${formatMoney(ticket.price)}</p>
      </div>
      <div className="ticket-actions">
        <button onClick={() => onCancel(ticket.id)}>Cancelar</button>
        <input placeholder="email destino" value={emailByTicket[ticket.id] || ''} onChange={e => setEmailByTicket({ ...emailByTicket, [ticket.id]: e.target.value })} />
        <button onClick={() => onTransfer(ticket.id, emailByTicket[ticket.id])}>Transferir</button>
      </div>
    </div>)}
  </section>
}

function Seller({ events, offers, reload, setMessage }) {
  const firstEvent = useMemo(() => events[0]?.id ? String(events[0].id) : '', [events])
  const [form, setForm] = useState({ event_id: firstEvent, title: '', price: 10000, quantity: 1, external_url: '' })

  useEffect(() => {
    if (!form.event_id && firstEvent) setForm(prev => ({ ...prev, event_id: firstEvent }))
  }, [firstEvent, form.event_id])

  async function submit(e) {
    e.preventDefault()
    try {
      const offer = await api.createOffer({ ...form, event_id: Number(form.event_id), price: Number(form.price), quantity: Number(form.quantity) })
      if (offer.scan_status === 'malicious') {
        setMessage('ALERTA: la publicación fue bloqueada porque el link fue marcado como malicioso')
      } else if (offer.scan_status === 'suspicious') {
        setMessage('ALERTA: la publicación quedó creada, pero el link fue marcado como sospechoso')
      } else if (offer.scan_status === 'pending') {
        setMessage('Link enviado a análisis. La publicación queda pendiente de verificación')
      } else {
        setMessage('Publicación creada correctamente')
      }
      setForm(prev => ({ ...prev, title: '', price: 10000, quantity: 1, external_url: '' }))
      await reload()
    } catch (err) {
      setMessage(err.message)
    }
  }
  return <div className="detail-layout">
    <section className="panel publish-panel">
      <h2>Crear publicación</h2>
      <p className="hint">Cada evento funciona como foro. El vendedor publica su oferta dentro del evento y el link queda registrado para análisis.</p>
      <form onSubmit={submit}>
        <select value={form.event_id} onChange={e => setForm({ ...form, event_id: e.target.value })}>
          <option value="">Seleccionar evento / foro</option>
          {events.map(e => <option key={e.id} value={e.id}>{e.title}</option>)}
        </select>
        <input placeholder="Título de publicación" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
        <input type="number" placeholder="Precio" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} />
        <input type="number" placeholder="Cantidad" value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} />
        <textarea
          className="long-url"
          placeholder="Link externo completo para analizar. Puede ser un link largo de phishing para pruebas controladas del honeypot."
          value={form.external_url}
          onChange={e => setForm({ ...form, external_url: e.target.value })}
          spellCheck="false"
        />
        <button>Publicar</button>
      </form>
      <p className="hint">Si el link es malicioso, la publicación se bloquea para compradores, pero queda visible como alerta administrativa.</p>
    </section>
    <section className="panel">
      <h2>Mis publicaciones</h2>
      {offers.length === 0 && <p>No hay publicaciones cargadas.</p>}
      {offers.map(o => <div className="table-row" key={o.id}>
        <div>
          <strong>{o.title}</strong>
          <p>{o.status} · {o.scan_status}</p>
          <small>{o.event?.title}</small>
          <small>{o.scan_verdict}</small>
        </div>
        <strong>${formatMoney(o.price)}</strong>
      </div>)}
    </section>
  </div>
}

function Admin({ events, reloadEvents, report, loadReport, alerts, reloadAlerts, setMessage }) {
  const [form, setForm] = useState(emptyEvent)
  async function submit(e) {
    e.preventDefault()
    try {
      await api.createEvent({ ...form, starts_at: new Date(form.starts_at).toISOString(), capacity: Number(form.capacity), duration_minutes: Number(form.duration_minutes) })
      setMessage('Evento creado')
      setForm(emptyEvent)
      await reloadEvents()
    } catch (err) {
      setMessage(err.message)
    }
  }
  return <div className="admin-layout">
    <section className="panel">
      <h2>Crear evento / foro</h2>
      <form onSubmit={submit}>
        <input placeholder="Título" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
        <textarea placeholder="Descripción" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
        <input placeholder="Categoría" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} />
        <input placeholder="Lugar" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} />
        <input type="datetime-local" value={form.starts_at} onChange={e => setForm({ ...form, starts_at: e.target.value })} />
        <input type="number" placeholder="Duración" value={form.duration_minutes} onChange={e => setForm({ ...form, duration_minutes: e.target.value })} />
        <input type="number" placeholder="Cupo" value={form.capacity} onChange={e => setForm({ ...form, capacity: e.target.value })} />
        <input placeholder="Imagen URL" value={form.image_url} onChange={e => setForm({ ...form, image_url: e.target.value })} />
        <button>Guardar evento</button>
      </form>
    </section>

    <section className="panel">
      <h2>Eventos y reportes</h2>
      {events.map(e => <div className="table-row" key={e.id}>
        <span>{e.title}</span>
        <div className="inline-actions"><button onClick={() => loadReport(e.id)}>Reporte</button><button onClick={async () => { await api.cancelEvent(e.id); setMessage('Evento cancelado'); await reloadEvents() }}>Cancelar</button></div>
      </div>)}
      {report && <div className="report">
        <h3>Reporte: {report.event.title}</h3>
        <p>Vendidas: {report.sold} / {report.capacity}</p>
        <p>Disponibles: {report.available}</p>
        <p>Ocupación: {report.occupation_pct.toFixed(2)}%</p>
      </div>}
    </section>

    <section className="panel admin-alerts">
      <div className="panel-title-row"><h2>Alertas del honeypot</h2><button onClick={reloadAlerts}>Actualizar</button></div>
      {alerts.length === 0 && <p>No hay publicaciones sospechosas o bloqueadas.</p>}
      {alerts.map(o => <div className="alert-row" key={o.id}>
        <div>
          <strong>{o.title}</strong>
          <p>{o.event?.title} · vendedor: {o.seller?.email}</p>
          <span className={`scan-badge ${o.scan_status === 'malicious' ? 'danger' : 'warning'}`}>{o.scan_status}</span>
          <small>{o.scan_verdict}</small>
          <small className="evidence-url">{o.external_url}</small>
        </div>
        <strong>{o.status}</strong>
      </div>)}
    </section>
  </div>
}

function formatMoney(value) {
  return Number(value || 0).toLocaleString('es-AR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })
}

export default App
