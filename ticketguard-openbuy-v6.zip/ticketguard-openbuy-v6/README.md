# TicketGuard OpenBuy v6

Sistema de gestión de foros de eventos y entradas con enfoque marketplace/OpenBuy. Cada foro permite comprar una entrada general y, por separado, ver publicaciones de usuarios para solicitar intercambios. El sistema conserva el enfoque honeypot controlado: registra publicaciones, analiza links y muestra alertas administrativas cuando detecta indicadores de phishing, scam o malware.

## Cambios principales de v6

- Se agregó phpMyAdmin para visualizar y administrar MySQL desde navegador.
- La compra dejó de estar dentro de cada publicación: ahora el foro tiene un botón general **Comprar entrada**.
- Las publicaciones ahora muestran **Solicitar intercambio**.
- Se agregó flujo de intercambio con bandeja de entrada/salida: aceptar cambia la titularidad de las entradas; rechazar anula la solicitud.
- Las entradas conservan ID, código, valor, asiento/descripción y titular para trazabilidad.
- Si el intercambio tiene diferencia de valor, se muestra el contacto para coordinar el pago externo. El saldo interno no se modifica.
- La actualización de contraseña ahora se abre como ventana emergente.
- Mis publicaciones bloqueadas se muestran al usuario únicamente como “Publicación bloqueada”.
- El panel de alertas incluye botón **Más información** con evidencia y botón **Limpiar alertas**.
- El honeypot registra metadatos defensivos: IP, User-Agent, headers HTTP, idioma, zona horaria, viewport, pantalla y otros datos básicos provistos por el navegador.

## Tecnologías utilizadas

- Backend: Go, Gin, GORM, MySQL, JWT y bcrypt.
- Frontend: React + Vite.
- Base de datos: MySQL 8.
- Visualización DB: phpMyAdmin.
- DevOps: Docker, Dockerfile y Docker Compose.
- Seguridad extra del proyecto: cliente de análisis de links para ofertas externas, con implementación mock local y adaptación preparada para VirusTotal si se configura `VT_API_KEY`.

## Cómo levantar todo

Si venís de la v5 o versiones anteriores, conviene limpiar los volúmenes porque cambió el esquema de base de datos:

```bash
docker compose down -v
```

Luego levantá todo:

```bash
docker compose build --no-cache
docker compose up
```

Frontend:

```text
http://localhost:5173
```

API backend:

```text
http://localhost:8080/api
```

phpMyAdmin:

```text
http://localhost:8081
```

Datos de MySQL/phpMyAdmin:

```text
Host: mysql          # dentro de Docker/phpMyAdmin
Host local: localhost
Port local: 3307
User: ticketguard
Password: ticketguard123
Database: ticketguard_db
```

## Usuarios iniciales

```text
Admin:        admin@ticketguard.test        / Admin123!
Usuario:      usuario@ticketguard.test      / Usuario123!
Intercambio:  intercambio@ticketguard.test  / Usuario123!
```

## Flujo de prueba sugerido v6

1. Entrar como usuario y abrir un foro.
2. Comprar una entrada desde el botón general del foro.
3. Ir a “Crear publicación”, asociar una entrada propia y publicar una propuesta de intercambio.
4. Entrar con otro usuario, comprar una entrada del mismo foro y solicitar intercambio en una publicación.
5. Volver al usuario dueño de la publicación y aceptar o rechazar desde “Mis entradas e intercambios”.
6. Entrar como admin, revisar alertas, abrir “Más información” y luego usar “Limpiar alertas”.
7. Abrir `http://localhost:8081` para inspeccionar tablas y relaciones desde phpMyAdmin.

## Endpoints principales

### Autenticación

```text
POST /api/auth/register
POST /api/auth/login
POST /api/me/password
```

### Público

```text
GET /api/events
GET /api/events/:id
GET /api/events/:id/offers
```

### Usuario autenticado

```text
POST /api/events/:id/buy
GET  /api/me/tickets
POST /api/tickets/:id/cancel
POST /api/tickets/:id/transfer
GET  /api/me/offers
POST /api/me/offers
POST /api/offers/:id/exchange
GET  /api/me/exchanges/inbox
GET  /api/me/exchanges/sent
POST /api/exchanges/:id/accept
POST /api/exchanges/:id/reject
```

### Administrador

```text
POST   /api/admin/events
PUT    /api/admin/events/:id
DELETE /api/admin/events/:id
GET    /api/admin/events/:id/report
GET    /api/admin/security/offers
POST   /api/admin/security/alerts/clear
```

## Tests del backend

```bash
cd backend
go test ./...
```

## Decisiones de diseño v6

1. La compra general del foro y el intercambio entre publicaciones quedan separados para cumplir el flujo pedido: comprar entrada no depende de una publicación.
2. Los intercambios se ejecutan dentro de una transacción de base de datos para que el cambio de titularidad sea atómico.
3. Las publicaciones bloqueadas no exponen detalles técnicos al usuario común; el detalle queda reservado al panel administrador.
4. El botón “Limpiar alertas” no borra evidencia: marca la alerta como limpiada para despejar el panel.
5. La telemetría del honeypot se limita a metadatos defensivos disponibles por HTTP/navegador. No accede a archivos, credenciales ni datos privados del dispositivo.
