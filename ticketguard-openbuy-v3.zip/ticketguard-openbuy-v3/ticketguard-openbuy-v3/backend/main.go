package main

import (
	"fmt"
	"log"
	"time"

	"ticketguard/backend/clients"
	"ticketguard/backend/config"
	"ticketguard/backend/controllers"
	"ticketguard/backend/dao"
	"ticketguard/backend/domain"
	"ticketguard/backend/services"
	"ticketguard/backend/utils"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

func main() {
	cfg := config.Load()
	db, err := connectWithRetry(cfg.DSN(), 20, 2*time.Second)
	if err != nil {
		log.Fatal(err)
	}
	if err := migrateAndSeed(db); err != nil {
		log.Fatal(err)
	}

	userDAO := dao.NewUserDAO(db)
	eventDAO := dao.NewEventDAO(db)
	offerDAO := dao.NewOfferDAO(db)
	ticketDAO := dao.NewTicketDAO(db)

	scanner := clients.NewLinkScanner(cfg.VTAPIKey)
	authService := services.NewAuthService(userDAO, cfg)
	eventService := services.NewEventService(eventDAO, ticketDAO)
	offerService := services.NewOfferService(offerDAO, eventDAO, scanner)
	ticketService := services.NewTicketService(db, userDAO, eventDAO, offerDAO, ticketDAO)
	walletService := services.NewWalletService(userDAO)

	router := controllers.SetupRouter(cfg, controllers.Controllers{
		Auth:    controllers.NewAuthController(authService),
		Events:  controllers.NewEventController(eventService),
		Offers:  controllers.NewOfferController(offerService),
		Tickets: controllers.NewTicketController(ticketService),
		Wallet:  controllers.NewWalletController(walletService),
	})

	addr := ":" + cfg.AppPort
	log.Printf("TicketGuard backend running on %s", addr)
	if err := router.Run(addr); err != nil {
		log.Fatal(err)
	}
}

func connectWithRetry(dsn string, attempts int, delay time.Duration) (*gorm.DB, error) {
	var lastErr error
	for i := 1; i <= attempts; i++ {
		db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
		if err == nil {
			return db, nil
		}
		lastErr = err
		log.Printf("database not ready, retry %d/%d", i, attempts)
		time.Sleep(delay)
	}
	return nil, lastErr
}

func migrateAndSeed(db *gorm.DB) error {
	if err := db.AutoMigrate(&domain.User{}, &domain.Event{}, &domain.Offer{}, &domain.Ticket{}); err != nil {
		return err
	}
	return seed(db)
}

func seed(db *gorm.DB) error {
	seedUser := func(name, email, password string, role domain.UserRole) (*domain.User, error) {
		var existing domain.User
		if err := db.Where("email = ?", domain.NormalizeEmail(email)).First(&existing).Error; err == nil {
			return &existing, nil
		}
		hash, err := utils.HashPassword(password)
		if err != nil {
			return nil, err
		}
		user := &domain.User{Name: name, Email: domain.NormalizeEmail(email), PasswordHash: hash, Role: role, Balance: 100000}
		return user, db.Create(user).Error
	}

	admin, err := seedUser("Admin Demo", "admin@ticketguard.test", "Admin123!", domain.RoleAdmin)
	if err != nil {
		return err
	}
	seller, err := seedUser("Vendedor Demo", "seller@ticketguard.test", "Seller123!", domain.RoleVendedor)
	if err != nil {
		return err
	}
	_, err = seedUser("Cliente Demo", "cliente@ticketguard.test", "Cliente123!", domain.RoleCliente)
	if err != nil {
		return err
	}

	var count int64
	db.Model(&domain.Event{}).Count(&count)
	if count == 0 {
		events := []domain.Event{
			{Title: "Festival Córdoba Tech", Description: "Foro de publicaciones para entradas del festival. Los vendedores pueden cargar ofertas y links externos para análisis.", Category: "Tecnología", Location: "Córdoba", StartsAt: time.Now().AddDate(0, 1, 0), DurationMinutes: 180, Capacity: 300, ImageURL: "https://images.unsplash.com/photo-1492684223066-81342ee5ff30", Status: domain.EventActive, CreatedByID: admin.ID},
			{Title: "Concierto OpenBuy", Description: "Foro de reventa controlada para conciertos. Cada publicación queda registrada como evidencia del honeypot.", Category: "Música", Location: "Buenos Aires", StartsAt: time.Now().AddDate(0, 2, 0), DurationMinutes: 120, Capacity: 500, ImageURL: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a", Status: domain.EventActive, CreatedByID: admin.ID},
			{Title: "Final Deportiva Federal", Description: "Foro para ofertas de entradas deportivas con control de cupo, monedero y transferencia.", Category: "Deportes", Location: "Córdoba", StartsAt: time.Now().AddDate(0, 1, 10), DurationMinutes: 150, Capacity: 750, ImageURL: "https://images.unsplash.com/photo-1540747913346-19e32dc3e97e", Status: domain.EventActive, CreatedByID: admin.ID},
			{Title: "Foro Teatro Centro", Description: "Publicaciones de entradas para obras y funciones. El sistema analiza los enlaces pegados por vendedores.", Category: "Teatro", Location: "Rosario", StartsAt: time.Now().AddDate(0, 1, 20), DurationMinutes: 100, Capacity: 240, ImageURL: "https://images.unsplash.com/photo-1503095396549-807759245b35", Status: domain.EventActive, CreatedByID: admin.ID},
			{Title: "Gaming & eSports Arena", Description: "Foro de entradas para torneos gaming. Útil para simular intentos de phishing sobre cuentas de juegos.", Category: "Gaming", Location: "Córdoba", StartsAt: time.Now().AddDate(0, 3, 0), DurationMinutes: 240, Capacity: 600, ImageURL: "https://images.unsplash.com/photo-1542751371-adc38448a05e", Status: domain.EventActive, CreatedByID: admin.ID},
			{Title: "Congreso Seguridad Digital", Description: "Foro académico para pruebas del flujo completo: ofertas, links sospechosos, alertas y reportes.", Category: "Conferencias", Location: "Mendoza", StartsAt: time.Now().AddDate(0, 2, 15), DurationMinutes: 300, Capacity: 400, ImageURL: "https://images.unsplash.com/photo-1515187029135-18ee286d815b", Status: domain.EventActive, CreatedByID: admin.ID},
		}
		for i := range events {
			if err := db.Create(&events[i]).Error; err != nil {
				return err
			}
		}
		var seededEvents []domain.Event
		if err := db.Find(&seededEvents).Error; err != nil {
			return err
		}
		for _, event := range seededEvents {
			offer := domain.Offer{EventID: event.ID, SellerID: seller.ID, Title: fmt.Sprintf("Entrada general - %s", event.Title), Price: 15000, Quantity: 20, ExternalURL: "https://tickets.example.com/evento-seguro", ScanStatus: domain.ScanSafe, ScanVerdict: "seed: link de demostración seguro", Status: domain.OfferActive}
			if err := db.Create(&offer).Error; err != nil {
				return err
			}
		}
	}
	return nil
}
