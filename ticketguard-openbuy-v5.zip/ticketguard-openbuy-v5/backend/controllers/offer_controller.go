package controllers

import (
	"ticketguard/backend/services"
	"ticketguard/backend/utils"

	"github.com/gin-gonic/gin"
)

type OfferController struct{ service *services.OfferService }

func NewOfferController(service *services.OfferService) *OfferController {
	return &OfferController{service: service}
}

func (h *OfferController) ListForEvent(c *gin.Context) {
	eventID, err := parseID(c.Param("id"))
	if err != nil {
		utils.Error(c, utils.ErrInvalidInput)
		return
	}
	offers, err := h.service.ListForEvent(eventID)
	if err != nil {
		utils.Error(c, err)
		return
	}
	utils.OK(c, offers)
}

func (h *OfferController) ListMine(c *gin.Context) {
	offers, err := h.service.ListByPublisher(currentUserID(c))
	if err != nil {
		utils.Error(c, err)
		return
	}
	utils.OK(c, offers)
}

func (h *OfferController) Create(c *gin.Context) {
	var input services.OfferInput
	if err := c.ShouldBindJSON(&input); err != nil {
		utils.Error(c, utils.ErrInvalidInput)
		return
	}
	evidence := services.OfferEvidenceInput{
		RequestIP:   c.ClientIP(),
		UserAgent:   c.Request.UserAgent(),
		BrowserData: c.GetHeader("Sec-CH-UA"),
	}
	offer, err := h.service.Create(c.Request.Context(), currentUserID(c), input, evidence)
	if err != nil {
		utils.Error(c, err)
		return
	}
	utils.Created(c, offer)
}

func (h *OfferController) ListFlagged(c *gin.Context) {
	offers, err := h.service.ListFlagged()
	if err != nil {
		utils.Error(c, err)
		return
	}
	utils.OK(c, offers)
}
