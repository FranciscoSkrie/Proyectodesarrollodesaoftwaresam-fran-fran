# Resumen de API REST v5

La API usa JSON y JWT Bearer Token.

## Status codes usados

- `200 OK`: lectura o acción exitosa.
- `201 Created`: recurso creado.
- `400 Bad Request`: entrada inválida.
- `401 Unauthorized`: falta token o token inválido.
- `403 Forbidden`: rol insuficiente.
- `404 Not Found`: recurso inexistente o no visible para el usuario.
- `409 Conflict`: conflicto de negocio.
- `500 Internal Server Error`: error inesperado.

## Auth

```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "usuario@ticketguard.test",
  "password": "Usuario123!"
}
```

Respuesta:

```json
{
  "token": "...",
  "user": { "id": 2, "name": "Usuario Demo", "email": "usuario@ticketguard.test", "role": "usuario" }
}
```

## Cambiar contraseña

```http
POST /api/me/password
Authorization: Bearer <token-usuario>
Content-Type: application/json

{
  "current_password": "Usuario123!",
  "new_password": "Nueva123!"
}
```

## Publicaciones del usuario

```http
GET /api/me/offers
Authorization: Bearer <token-usuario>
```

```http
POST /api/me/offers
Authorization: Bearer <token-usuario>
Content-Type: application/json

{
  "event_id": 1,
  "title": "Entrada general",
  "price": 15000,
  "quantity": 1,
  "external_url": "https://example.com"
}
```

## Entradas

```http
POST /api/offers/:id/buy
GET  /api/me/tickets
POST /api/tickets/:id/cancel
POST /api/tickets/:id/transfer
```

Transferencia por ID de usuario:

```json
{ "user_id": 3 }
```

## Alertas del honeypot

Solo administrador:

```http
GET /api/admin/security/offers
Authorization: Bearer <token-admin>
```

Devuelve publicaciones bloqueadas o sospechosas, incluyendo foro, usuario, IP capturada, navegador, URL pegada y veredicto del scanner.
