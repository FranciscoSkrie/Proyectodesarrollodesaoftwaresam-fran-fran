import { useEffect, useMemo, useRef, useState } from 'react'
import { api } from './api.js'

const emptyEvent = {
  title: '',
  description: '',
  category: '',
  location: '',
  starts_at: '',
  duration_minutes: 120,
  capacity: 100,
  image_url: ''
}

const SESSION_VERSION = 'ticketguard-openbuy-v5'

function clearStoredSession() {
  localStorage.removeItem('token')
  localStorage.removeItem('user')
  localStorage.removeItem('session_version')
}

function loadStoredSession() {
  const version = localStorage.getItem('session_version')
  const token = localStorage.getItem('token')
  const user = localStorage.getItem('user')

  // v5 invalida sesiones viejas por el cambio de permisos.
  if (version !== SESSION_VERSION || !token || !user) {
    clearStoredSession()
    return null
  }

  try {
    return { token, user: normalizeUser(JSON.parse(user)) }
  } catch {
    clearStoredSession()
    return null
  }
}

function normalizeUser(user) {
  if (!user) return user
  return user
}

function App() {
  const [session, setSession] = useState(loadStoredSession)
  const [view, setView] = useState('home')
  const [events, setEvents] = useState([])
  const [selectedEvent, setSelectedEvent] = useState(null)
  const [offers, setOffers] = useState([])
  const [tickets, setTickets] = useState([])
  const [userOffers, setUserOffers] = useState([])
  const [report, setReport] = useState(null)
  const [securityAlerts, setSecurityAlerts] = useState([])
  const [message, setMessage] = useState('')
  const [filters, setFilters] = useState({ q: '', category: '' })
  const syncingHistory = useRef(false)

  const role = session?.user?.role || 'anon'
  const isUser = role === 'usuario'
  const isAdmin = role === 'admin'

  useEffect(() => { loadEvents() }, [])

  useEffect(() => {
    if (!message) return
    const id = setTimeout(() => setMessage(''), 3000)
    return () => clearTimeout(id)
  }, [message])

  useEffect(() => {
    window.history.replaceState({ ticketguard: true, view: 'home' }, '', '#home')
    const onPopState = (event) => {
      syncingHistory.current = true
      const nextView = event.state?.view || 'home'
      setView(nextView)
    }
    window.addEventListener('popstate', onPopState)
    return () => window.removeEventListener('popstate', onPopState)
  }, [])

  useEffect(() => {
    if (syncingHistory.current) {
      syncingHistory.current = false
      return
    }
    const state = window.history.state
    if (!state?.ticketguard || state.view !== view) {
      window.history.pushState({ ticketguard: true, view }, '', `#${view}`)
    }
  }, [view])

  async function loadEvents(nextFilters = filters) {
    try {
      setEvents(await api.events(nextFilters))
    } catch (err) {
      setMessage(err.message)
    }
  }

  function saveSession(resp) {
    const normalized = { ...resp, user: normalizeUser(resp.user) }
    localStorage.setItem('session_version', SESSION_VERSION)
    localStorage.setItem('token', normalized.token)
    localStorage.setItem('user', JSON.stringify(normalized.user))
    setSession(normalized)
    setView('account')
    setMessage('Sesión iniciada correctamente')
  }

  function logout() {
    clearStoredSession()
    setSession(null)
    setTickets([])
    setUserOffers([])
    setSecurityAlerts([])
    setView('home')
    setMessage('Sesión cerrada')
  }

  async function openEvent(event) {
    try {
      setSelectedEvent(event)
      setOffers(await api.offers(event.id))
      setView('detail')
    } catch (err) {
      setMessage(err.message)
    }
  }

  async function loadTickets() {
    if (!isUser) {
      setMessage('Para ver entradas tenés que iniciar sesión como usuario')
      return
    }
    try {
      setTickets(await api.myTickets())
      setView('tickets')
    } catch (err) {
      setMessage(err.message)
    }
  }

  async function loadUserOffers() {
    if (!isUser) {
      setMessage('Para crear publicaciones tenés que iniciar sesión como usuario')
      return
    }
    try {
      setUserOffers(await api.myOffers())
      setView('publish')
    } catch (err) {
      setMessage(err.message)
    }
  }

  async function loadReport(eventId) {
    try {
      setReport(await api.report(eventId))
    } catch (err) {
      setMessage(err.message)
    }
  }

  async function loadSecurityAlerts() {
    try {
      setSecurityAlerts(await api.securityOffers())
    } catch (err) {
      setMessage(err.message)
    }
  }

  function goPublish() {
    if (!session) {
      setView('login')
      setMessage('Iniciá sesión como usuario para crear publicaciones')
      return
    }
    if (!isUser) {
      setMessage('Solo una cuenta de usuario puede crear publicaciones')
      return
    }
    loadUserOffers()
  }

  function goAdmin() {
    if (!isAdmin) {
      setMessage('Solo administración puede ver el panel de gestión')
      return
    }
    loadSecurityAlerts()
    setView('admin')
  }

  function goAccount() {
    if (!session) {
      setView('login')
      return
    }
    setView('account')
  }

  function requireLogin() {
    setView('login')
    setMessage('Iniciá sesión con una cuenta de usuario para registrar entradas')
  }

  return (
    <div className="market-shell">
      <Sidebar
        session={session}
        view={view}
        filters={filters}
        setFilters={setFilters}
        onSearch={loadEvents}
        setView={setView}
        onAccount={goAccount}
        onTickets={loadTickets}
        onPublish={goPublish}
        onAdmin={goAdmin}
        isUser={isUser}
        isAdmin={isAdmin}
        onLogout={logout}
      />

      <main className="content">
        <div className="content-top">
          <h2>{titleFor(view)}</h2>
        </div>

        {message && <div className="message" onClick={() => setMessage('')}>{message}</div>}

        {view === 'home' && <Home events={events} onOpen={openEvent} />}
        {view === 'login' && <Login onLogin={saveSession} setMessage={setMessage} />}
        {view === 'account' && <Account session={session} onTickets={loadTickets} onPublish={goPublish} onAdmin={goAdmin} onLogout={logout} isUser={isUser} isAdmin={isAdmin} setMessage={setMessage} />}
        {view === 'detail' && <Detail event={selectedEvent} offers={offers} session={session} isUser={isUser} onRequireLogin={requireLogin} onRegisterTicket={async (id) => {
          try {
            await api.buy(id)
            setMessage('Entrada registrada. Coordiná la compra o trueque por fuera de la plataforma.')
            await loadTickets()
          } catch (err) {
            setMessage(err.message)
          }
        }} />}
        {view === 'tickets' && <Tickets tickets={tickets} onCancel={async (id) => {
          try {
            await api.cancelTicket(id)
            setMessage('Entrada cancelada')
            await loadTickets()
          } catch (err) {
            setMessage(err.message)
          }
        }} onTransfer={async (id, userId) => {
          try {
            await api.transferTicket(id, userId)
            setMessage('Entrada transferida')
            await loadTickets()
          } catch (err) {
            setMessage(err.message)
          }
        }} />}
        {view === 'publish' && <Publish events={events} offers={userOffers} reload={loadUserOffers} setMessage={setMessage} />}
        {view === 'admin' && <Admin events={events} reloadEvents={loadEvents} report={report} loadReport={loadReport} alerts={securityAlerts} reloadAlerts={loadSecurityAlerts} setMessage={setMessage} />}
      </main>
    </div>
  )
}

function titleFor(view) {
  const titles = {
    home: 'Foros de eventos destacados',
    login: 'Tu cuenta',
    account: 'Tu cuenta',
    detail: 'Publicaciones del evento',
    tickets: 'Mis entradas',
    publish: 'Crear publicación',
    admin: 'Panel de gestión y alertas'
  }
  return titles[view] || 'Marketplace'
}

function Sidebar({ session, view, filters, setFilters, onSearch, setView, onAccount, onTickets, onPublish, onAdmin, isUser, isAdmin, onLogout }) {
  function submit(e) {
    e.preventDefault()
    onSearch()
    setView('home')
  }

  function setCategory(category) {
    const next = { ...filters, category }
    setFilters(next)
    onSearch(next)
    setView('home')
  }

  return (
    <aside className="sidebar">
      <div className="brand-row">
        <h1>Marketplace</h1>
        <button className="round-btn" title="Configuración de cuenta" aria-label="Abrir cuenta o iniciar sesión" onClick={onAccount}>⚙</button>
      </div>

      <form className="search-box" onSubmit={submit}>
        <span>⌕</span>
        <input
          placeholder="Buscar en Marketplace"
          value={filters.q}
          onChange={e => setFilters({ ...filters, q: e.target.value })}
        />
      </form>

      <div className="side-menu">
        <button className={view === 'home' ? 'side-active' : ''} onClick={() => { setView('home'); onSearch() }}>🏪 Explorar todo</button>
        <button className={view === 'account' || view === 'login' ? 'side-active' : ''} onClick={onAccount}>👤 Tu cuenta</button>
        {isUser && <button className="create-btn" onClick={onPublish}>＋ Crear publicación</button>}
        {isUser && <button className={view === 'tickets' ? 'side-active' : ''} onClick={onTickets}>🎟️ Mis entradas</button>}
        {isAdmin && <button className={view === 'admin' ? 'side-active' : ''} onClick={onAdmin}>🛡️ Gestión y alertas</button>}
        {session && <button onClick={onLogout}>↩ Salir</button>}
      </div>

      <hr />

      <section className="sidebar-section">
        <h3>Filtros</h3>
        <input
          placeholder="Categoría"
          value={filters.category}
          onChange={e => setFilters({ ...filters, category: e.target.value })}
        />
        <button onClick={() => { onSearch(); setView('home') }}>Aplicar filtros</button>
      </section>

      <section className="sidebar-section categories">
        <h3>Categorías</h3>
        <button onClick={() => setCategory('Tecnología')}>💻 Tecnología</button>
        <button onClick={() => setCategory('Música')}>🎵 Música</button>
        <button onClick={() => setCategory('Deportes')}>⚽ Deportes</button>
        <button onClick={() => setCategory('Teatro')}>🎭 Teatro</button>
        <button onClick={() => setCategory('Gaming')}>🎮 Gaming</button>
        <button onClick={() => setCategory('Conferencias')}>🎤 Conferencias</button>
      </section>
    </aside>
  )
}

function Home({ events, onOpen }) {
  return (
    <section className="market-grid">
      {events.length === 0 && <div className="empty-state">No se encontraron foros con esos filtros.</div>}
      {events.map(event => <article className="listing-card" key={event.id} onClick={() => onOpen(event)}>
        <div className="thumb">
          {event.image_url ? <img src={event.image_url} alt={event.title} /> : <span>{event.category || 'Foro'}</span>}
        </div>
        <div className="listing-body">
          <strong>{event.title}</strong>
          <p>{event.location}</p>
          <small>{new Date(event.starts_at).toLocaleString()} · {event.category}</small>
          <small>Foro abierto para publicaciones de usuarios</small>
        </div>
      </article>)}
    </section>
  )
}

function Login({ onLogin, setMessage }) {
  const [mode, setMode] = useState('login')
  const [form, setForm] = useState({ name: '', email: 'usuario@ticketguard.test', password: 'Usuario123!' })
  async function submit(e) {
    e.preventDefault()
    try {
      const resp = mode === 'login' ? await api.login(form) : await api.register(form)
      onLogin(resp)
    } catch (err) {
      setMessage(err.message)
    }
  }
  return <section className="panel narrow-panel">
    <h2>{mode === 'login' ? 'Iniciar sesión' : 'Crear cuenta'}</h2>
    <p className="hint">Sin iniciar sesión solo se puede explorar el catálogo público. Publicar, registrar entradas, transferir y gestionar alertas queda bloqueado hasta autenticar la cuenta correcta.</p>
    <form onSubmit={submit}>
      {mode === 'register' && <input placeholder="Nombre" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />}
      <input placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
      <input placeholder="Password" type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} />
      <button>{mode === 'login' ? 'Entrar' : 'Registrarme'}</button>
    </form>
    <button className="text-btn" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Crear una cuenta' : 'Ya tengo cuenta'}</button>
    <div className="demo-box">
      <p><strong>Demo</strong></p>
      <p>admin@ticketguard.test / Admin123!</p>
      <p>usuario@ticketguard.test / Usuario123!</p>
    </div>
  </section>
}

function Account({ session, onTickets, onPublish, onAdmin, onLogout, isUser, isAdmin, setMessage }) {
  if (!session) return null
  return <section className="account-grid">
    <div className="panel account-main">
      <h2>Cuenta conectada</h2>
      <p className="hint">Desde acá se accede solo a las acciones habilitadas para esta sesión.</p>
      <div className="account-summary">
        <span>ID de usuario</span>
        <strong>{session.user.id}</strong>
      </div>
      <div className="account-summary">
        <span>Correo</span>
        <strong>{session.user.email}</strong>
      </div>
      <div className="account-actions">
        {isUser && <button onClick={onTickets}>Ver mis entradas</button>}
        {isUser && <button onClick={onPublish}>Crear publicación</button>}
        {isAdmin && <button onClick={onAdmin}>Ver gestión y alertas</button>}
        <button className="secondary-btn" onClick={onLogout}>Salir</button>
      </div>
    </div>
    <div className="panel account-help">
      <h2>Accesos por sesión</h2>
      <p>La sesión sin login solo puede explorar foros. Las publicaciones, entradas, transferencias y alertas se validan contra el backend.</p>
      <p>Cada publicación funciona como parte del honeypot: el link externo se analiza y queda registrado como evidencia administrativa si resulta sospechoso.</p>
      <ChangePasswordForm setMessage={setMessage} />
    </div>
  </section>
}

function ChangePasswordForm({ setMessage }) {
  const [form, setForm] = useState({ current_password: '', new_password: '' })
  async function submit(e) {
    e.preventDefault()
    try {
      await api.changePassword(form)
      setForm({ current_password: '', new_password: '' })
      setMessage('Contraseña actualizada')
    } catch (err) {
      setMessage(err.message)
    }
  }
  return <form className="password-form" onSubmit={submit}>
    <h3>Cambiar contraseña</h3>
    <input type="password" placeholder="Contraseña actual" value={form.current_password} onChange={e => setForm({ ...form, current_password: e.target.value })} />
    <input type="password" placeholder="Nueva contraseña" value={form.new_password} onChange={e => setForm({ ...form, new_password: e.target.value })} />
    <button>Actualizar contraseña</button>
  </form>
}

function Detail({ event, offers, session, isUser, onRequireLogin, onRegisterTicket }) {
  if (!event) return null
  return <div className="detail-layout">
    <section className="panel detail-panel">
      {event.image_url && <img className="detail-image" src={event.image_url} alt={event.title} />}
      <h2>{event.title}</h2>
      <p>{event.description}</p>
      <div className="meta-list two-cols">
        <span><strong>Lugar</strong>{event.location}</span>
        <span><strong>Fecha</strong>{new Date(event.starts_at).toLocaleString()}</span>
      </div>
    </section>
    <section className="panel">
      <h2>Publicaciones de usuarios</h2>
      {offers.length === 0 && <p>No hay publicaciones activas.</p>}
      {offers.map(offer => <OfferRow offer={offer} key={offer.id} session={session} isUser={isUser} onRequireLogin={onRequireLogin} onRegisterTicket={onRegisterTicket} />)}
      {!session && <p className="hint">Para registrar una entrada o coordinar una publicación necesitás iniciar sesión.</p>}
      {session && !isUser && <p className="hint">Esta cuenta puede explorar y administrar, pero las publicaciones y entradas pertenecen a cuentas de usuario.</p>}
    </section>
  </div>
}

function OfferRow({ offer, session, isUser, onRequireLogin, onRegisterTicket }) {
  const riskClass = offer.scan_status === 'malicious' ? 'danger' : offer.scan_status === 'suspicious' ? 'warning' : offer.scan_status === 'pending' ? 'pending' : 'safe'
  const blocked = offer.status === 'blocked' || offer.quantity <= 0
  const canRegister = Boolean(session && isUser && !blocked)
  const label = offer.status === 'blocked' ? 'Publicación bloqueada' : !session ? 'Iniciar sesión' : !isUser ? 'Solo usuarios' : offer.quantity <= 0 ? 'No disponible' : 'Coordinar entrada'
  const disabled = Boolean(session && (!isUser || blocked))
  return <div className="offer-row">
    <div>
      <strong>{offer.title}</strong>
      <p>Referencia: ${formatMoney(offer.price)}</p>
      <span className={`scan-badge ${riskClass}`}>{offer.scan_status}</span>
      <small>{offer.scan_verdict}</small>
    </div>
    <button disabled={disabled} onClick={() => canRegister ? onRegisterTicket(offer.id) : onRequireLogin()}>{label}</button>
  </div>
}

function Tickets({ tickets, onCancel, onTransfer }) {
  const [userIdByTicket, setUserIdByTicket] = useState({})
  return <section className="panel">
    <h2>Mis entradas</h2>
    {tickets.length === 0 && <p>Todavía no tenés entradas.</p>}
    {tickets.map(ticket => <div className="table-row" key={ticket.id}>
      <div>
        <strong>{ticket.event?.title}</strong>
        <p>Código: {ticket.code} · Estado: {ticket.status} · Referencia: ${formatMoney(ticket.price)}</p>
      </div>
      <div className="ticket-actions">
        <button onClick={() => onCancel(ticket.id)}>Cancelar</button>
        <input type="number" min="1" placeholder="ID usuario destino" value={userIdByTicket[ticket.id] || ''} onChange={e => setUserIdByTicket({ ...userIdByTicket, [ticket.id]: e.target.value })} />
        <button onClick={() => onTransfer(ticket.id, userIdByTicket[ticket.id])}>Transferir</button>
      </div>
    </div>)}
  </section>
}

function Publish({ events, offers, reload, setMessage }) {
  const firstEvent = useMemo(() => events[0]?.id ? String(events[0].id) : '', [events])
  const [form, setForm] = useState({ event_id: firstEvent, title: '', price: 10000, quantity: 1, external_url: '' })

  useEffect(() => {
    if (!form.event_id && firstEvent) setForm(prev => ({ ...prev, event_id: firstEvent }))
  }, [firstEvent, form.event_id])

  async function submit(e) {
    e.preventDefault()
    try {
      const offer = await api.createOffer({ ...form, event_id: Number(form.event_id), price: Number(form.price), quantity: Number(form.quantity) })
      if (offer.status === 'blocked') {
        setMessage('Publicación bloqueada')
      } else if (offer.scan_status === 'pending') {
        setMessage('Publicación recibida. Queda pendiente de revisión')
      } else {
        setMessage('Publicación creada correctamente')
      }
      setForm(prev => ({ ...prev, title: '', price: 10000, quantity: 1, external_url: '' }))
      await reload()
    } catch (err) {
      setMessage(err.message)
    }
  }
  return <div className="detail-layout">
    <section className="panel publish-panel">
      <h2>Crear publicación</h2>
      <p className="hint">Cada foro permite publicar una entrada, un link externo o una propuesta de trueque. La plataforma no usa dinero interno.</p>
      <form onSubmit={submit}>
        <select value={form.event_id} onChange={e => setForm({ ...form, event_id: e.target.value })}>
          <option value="">Seleccionar foro</option>
          {events.map(e => <option key={e.id} value={e.id}>{e.title}</option>)}
        </select>
        <input placeholder="Título de publicación" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
        <input type="number" placeholder="Referencia $ / trueque" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} />
        <input type="number" placeholder="Cantidad de entradas" value={form.quantity} onChange={e => setForm({ ...form, quantity: e.target.value })} />
        <textarea
          className="long-url"
          placeholder="Link externo completo para analizar. Puede ser un link largo de phishing para pruebas controladas del honeypot."
          value={form.external_url}
          onChange={e => setForm({ ...form, external_url: e.target.value })}
          spellCheck="false"
        />
        <button>Publicar</button>
      </form>
      <p className="hint">Si el link es malicioso, al usuario solo se le informa que la publicación fue bloqueada.</p>
    </section>
    <section className="panel">
      <h2>Mis publicaciones</h2>
      {offers.length === 0 && <p>No hay publicaciones cargadas.</p>}
      {offers.map(o => <div className="table-row" key={o.id}>
        <div>
          <strong>{o.title}</strong>
          <p>{publicOfferStatus(o)}</p>
          <small>{o.event?.title}</small>
        </div>
        <strong>${formatMoney(o.price)}</strong>
      </div>)}
    </section>
  </div>
}

function publicOfferStatus(offer) {
  if (offer.status === 'blocked') return 'Publicación bloqueada'
  if (offer.status === 'paused') return 'Publicación pausada'
  return 'Publicación activa'
}

function Admin({ events, reloadEvents, report, loadReport, alerts, reloadAlerts, setMessage }) {
  const [form, setForm] = useState(emptyEvent)
  async function submit(e) {
    e.preventDefault()
    try {
      await api.createEvent({ ...form, starts_at: new Date(form.starts_at).toISOString(), capacity: Number(form.capacity), duration_minutes: Number(form.duration_minutes) })
      setMessage('Foro creado')
      setForm(emptyEvent)
      await reloadEvents()
    } catch (err) {
      setMessage(err.message)
    }
  }
  return <div className="admin-layout">
    <section className="panel">
      <h2>Crear foro</h2>
      <form onSubmit={submit}>
        <input placeholder="Título" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} />
        <textarea placeholder="Descripción" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
        <input placeholder="Categoría" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} />
        <input placeholder="Lugar" value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} />
        <input type="datetime-local" value={form.starts_at} onChange={e => setForm({ ...form, starts_at: e.target.value })} />
        <input type="number" placeholder="Duración" value={form.duration_minutes} onChange={e => setForm({ ...form, duration_minutes: e.target.value })} />
        <input type="number" placeholder="Capacidad administrativa" value={form.capacity} onChange={e => setForm({ ...form, capacity: e.target.value })} />
        <input placeholder="Imagen URL" value={form.image_url} onChange={e => setForm({ ...form, image_url: e.target.value })} />
        <button>Guardar foro</button>
      </form>
    </section>

    <section className="panel">
      <h2>Foros y reportes</h2>
      {events.map(e => <div className="table-row" key={e.id}>
        <span>{e.title}</span>
        <div className="inline-actions"><button onClick={() => loadReport(e.id)}>Reporte</button><button onClick={async () => { await api.cancelEvent(e.id); setMessage('Foro cancelado'); await reloadEvents() }}>Cancelar</button></div>
      </div>)}
      {report && <div className="report">
        <h3>Reporte: {report.event.title}</h3>
        <p>Entradas registradas: {report.sold}</p>
        <p>Capacidad administrativa: {report.capacity}</p>
        <p>Disponibilidad estimada: {report.available}</p>
        <p>Ocupación: {report.occupation_pct.toFixed(2)}%</p>
      </div>}
    </section>

    <section className="panel admin-alerts">
      <div className="panel-title-row"><h2>Alertas del honeypot</h2><button onClick={reloadAlerts}>Actualizar</button></div>
      {alerts.length === 0 && <p>No hay publicaciones sospechosas o bloqueadas.</p>}
      {alerts.map(o => <div className="alert-row" key={o.id}>
        <div>
          <strong>{o.title}</strong>
          <p>{o.event?.title} · usuario: {o.request_user_name || o.publisher?.name || 'sin nombre'} ({o.request_user_email || o.publisher?.email})</p>
          <p>IP capturada: {o.request_ip || 'sin dato'}</p>
          <p>Navegador: {o.browser_data || o.user_agent || 'sin dato'}</p>
          <span className={`scan-badge ${o.scan_status === 'malicious' ? 'danger' : 'warning'}`}>{o.scan_status}</span>
          <small>{o.scan_verdict}</small>
          <small className="evidence-url">{o.external_url}</small>
        </div>
        <strong>{o.status}</strong>
      </div>)}
    </section>
  </div>
}

function formatMoney(value) {
  return Number(value || 0).toLocaleString('es-AR', { minimumFractionDigits: 0, maximumFractionDigits: 0 })
}

export default App
