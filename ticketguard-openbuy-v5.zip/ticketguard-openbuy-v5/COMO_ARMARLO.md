# Cómo armar el proyecto como rompecabezas — v5

## 1. Descomprimir

Descomprimí `ticketguard-openbuy-v5.zip` en una carpeta de trabajo.

## 2. Variables de entorno

El ZIP ya trae un `.env` de desarrollo. Si querés rehacerlo manualmente, copiá `.env.example` y renombralo como `.env`.

## 3. Levantar todo con Docker

Desde la raíz del proyecto:

```bash
docker compose build --no-cache
docker compose up
```

Esto levanta:

- MySQL en `localhost:3307`
- Backend Go en `localhost:8080`
- Frontend React en `localhost:5173`

## 4. Entrar al sistema

Abrí:

```text
http://localhost:5173
```

Usuarios demo:

```text
Admin:   admin@ticketguard.test   / Admin123!
Usuario: usuario@ticketguard.test / Usuario123!
```

## 5. Orden de prueba recomendado

1. Entrá como admin y mirá el panel de gestión de foros.
2. Entrá como usuario y creá una publicación.
3. Pegá un link largo o sospechoso para probar el honeypot.
4. Registrá una entrada desde una publicación.
5. Entrá a “Mis Entradas” para cancelar o transferir por ID de usuario.
6. Entrá como admin y revisá el reporte del foro y las alertas del honeypot.

## 6. Si algo falla

- Verificá que Docker Desktop esté abierto.
- Verificá que el puerto `8080`, `5173` o `3307` no esté ocupado.
- Para reiniciar desde cero:

```bash
docker compose down -v
docker compose build --no-cache
docker compose up
```

El `-v` borra el volumen de MySQL, por eso reinicia la base de datos desde cero.

## Actualización v5

Cambios principales:

- Se eliminó el monedero del flujo visible.
- Se fusionaron los roles Cliente y Vendedor en un único rol visible: Usuario.
- El Usuario puede publicar, registrar entradas, cancelar y transferir.
- La transferencia se hace por ID de usuario.
- La alerta de sesión iniciada dura 3 segundos.
- El botón de volver atrás del navegador mantiene la navegación interna de la SPA.
- Las publicaciones bloqueadas se informan al publicador solo como “Publicación bloqueada”.
- El admin ve evidencia del honeypot: usuario, IP, navegador, URL y veredicto.
