# TicketGuard OpenBuy v5

Sistema de gestión de foros de eventos y entradas con enfoque marketplace/OpenBuy. Cada foro permite que un usuario publique una entrada, un enlace externo o una propuesta de trueque. El sistema funciona como honeypot controlado: registra publicaciones, analiza links y muestra alertas administrativas cuando detecta indicadores de phishing, scam o malware.

## Cambios principales de v5

- Se eliminó el monedero del flujo visible y de las rutas usadas por el frontend.
- Se fusionaron los perfiles Cliente y Vendedor en un único rol visible: Usuario.
- Un Usuario puede explorar, publicar, registrar entradas, cancelar y transferir entradas.
- La transferencia de entradas ahora se realiza por ID de usuario.
- La alerta de sesión iniciada desaparece automáticamente a los 3 segundos.
- Las publicaciones bloqueadas se muestran al publicador solo como “Publicación bloqueada”, sin veredicto técnico.
- El panel administrativo conserva la evidencia del honeypot: IP, nombre/email del usuario, navegador, URL y veredicto.

## Tecnologías utilizadas

- Backend: Go, Gin, GORM, MySQL, JWT y bcrypt.
- Frontend: React + Vite.
- Base de datos: MySQL 8.
- DevOps: Docker, Dockerfile y Docker Compose.
- Seguridad extra del proyecto: cliente de análisis de links para ofertas externas, con implementación mock local y adaptación preparada para VirusTotal si se configura `VT_API_KEY`.

## Estructura del proyecto

```text
ticketguard-openbuy/
├── backend/
│   ├── clients/        # clientes externos, como análisis de links
│   ├── config/         # variables de entorno y conexión
│   ├── controllers/    # handlers HTTP
│   ├── dao/            # acceso a datos con GORM
│   ├── domain/         # entidades del negocio
│   ├── middleware/     # autenticación/autorización
│   ├── services/       # lógica de negocio
│   ├── utils/          # JWT, password y respuestas
│   └── main.go
├── frontend/
│   └── src/
├── docs/
├── docker-compose.yml
├── .env.example
└── .env
```

## Cómo levantar todo

1. El ZIP ya trae un `.env` de desarrollo para que Docker Compose levante sin error. Si querés regenerarlo, copiá `.env.example` como `.env`.

2. Si venís de una versión anterior y querés evitar datos viejos en la base:

```bash
docker compose down -v
```

3. Levantá el sistema completo:

```bash
docker compose build --no-cache
docker compose up
```

4. Abrí el frontend:

```text
http://localhost:5173
```

5. API backend:

```text
http://localhost:8080/api
```

6. MySQL desde DBeaver/TablePlus, si querés inspeccionar:

```text
Host: localhost
Port: 3307
User: ticketguard
Password: ticketguard123
Database: ticketguard_db
```

## Usuarios iniciales cargados por seed

```text
Admin:   admin@ticketguard.test   / Admin123!
Usuario: usuario@ticketguard.test / Usuario123!
```

## Flujo de prueba sugerido

1. Entrar como admin y crear un foro.
2. Entrar como usuario y crear una publicación dentro de un foro.
3. Pegar una URL larga o sospechosa en una publicación para probar el flujo de alerta.
4. Entrar como usuario, registrar una entrada desde una publicación y luego ver “Mis Entradas”.
5. Cancelar una entrada o transferirla a otro usuario por ID.
6. Entrar como admin y ver reportes y alertas del honeypot.

## Endpoints principales

### Autenticación

```text
POST /api/auth/register
POST /api/auth/login
POST /api/me/password
```

### Público

```text
GET /api/events
GET /api/events/:id
GET /api/events/:id/offers
```

### Usuario autenticado

```text
POST /api/offers/:id/buy
GET  /api/me/tickets
POST /api/tickets/:id/cancel
POST /api/tickets/:id/transfer
GET  /api/me/offers
POST /api/me/offers
```

### Administrador

```text
POST   /api/admin/events
PUT    /api/admin/events/:id
DELETE /api/admin/events/:id
GET    /api/admin/events/:id/report
GET    /api/admin/security/offers
```

## Tests del backend

```bash
cd backend
go test ./...
```

También podés obtener cobertura:

```bash
go test ./... -cover
```

## Decisiones de diseño v5

1. Las publicaciones, entradas, cancelaciones y transferencias se resuelven en la capa de servicios. Los controladores solo parsean HTTP, validan entrada superficial y devuelven status codes.
2. La capa DAO encapsula GORM y evita que los controladores tengan consultas o SQL.
3. La sesión sin autenticar solo explora el catálogo público. Las acciones sensibles están protegidas por JWT.
4. Los tickets no se eliminan físicamente cuando se cancelan: pasan a estado `cancelled`. Esto conserva historial y permite que el reporte sea auditable.
5. El sistema ya no usa dinero interno ni monedero. El precio queda como referencia informativa para coordinar por fuera de la plataforma.
6. Las contraseñas se guardan con bcrypt, no en texto plano.
7. Los links publicados pasan por un `LinkScanner`. Sin API key funciona con un mock local; con `VT_API_KEY` queda preparado para integrar VirusTotal.
8. Las alertas administrativas guardan evidencia útil para informe: usuario, correo, IP, navegador, URL y resultado del análisis.

## Diagrama de base de datos

El diagrama fuente está en:

```text
docs/db-diagram.mmd
```

Podés pegarlo en un visor Mermaid para exportarlo como imagen e incrustarlo en el README final del repositorio.
